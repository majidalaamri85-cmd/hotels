from django.urls import path
from . import views
urlpatterns=[path('',views.dashboard,name='dashboard'),path('hotels/new/',views.hotel_create,name='hotel_create'),path('evaluations/new/',views.evaluation_create,name='evaluation_create'),path('evaluations/<int:pk>/',views.evaluation_detail,name='evaluation_detail'),path('evaluations/<int:pk>/report.docx',views.report_docx,name='report_docx')]
