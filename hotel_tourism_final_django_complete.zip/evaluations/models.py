from django.db import models
from django.contrib.auth.models import User

class Hotel(models.Model):
    STAR_CHOICES=[(1,'نجمة واحدة'),(2,'نجمتان'),(3,'ثلاث نجوم'),(4,'أربع نجوم'),(5,'خمس نجوم')]
    name=models.CharField(max_length=255)
    governorate=models.CharField(max_length=120, blank=True)
    wilayat=models.CharField(max_length=120, blank=True)
    license_no=models.CharField(max_length=100, blank=True)
    rooms_count=models.PositiveIntegerField(default=0)
    target_stars=models.PositiveSmallIntegerField(choices=STAR_CHOICES, default=3)
    phone=models.CharField(max_length=50, blank=True)
    email=models.EmailField(blank=True)
    latitude=models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    longitude=models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    def __str__(self): return self.name

class Section(models.Model):
    code=models.CharField(max_length=20, unique=True)
    title=models.CharField(max_length=255)
    order=models.PositiveIntegerField(default=0)
    def __str__(self): return f'{self.code} - {self.title}'

class SubSection(models.Model):
    section=models.ForeignKey(Section,on_delete=models.CASCADE,related_name='subsections')
    code=models.CharField(max_length=20, unique=True)
    title=models.CharField(max_length=255)
    order=models.PositiveIntegerField(default=0)
    def __str__(self): return f'{self.code} - {self.title}'

class Criterion(models.Model):
    subsection=models.ForeignKey(SubSection,on_delete=models.CASCADE,related_name='criteria')
    code=models.CharField(max_length=30, unique=True)
    title=models.TextField()
    one_star=models.TextField(blank=True)
    two_star=models.TextField(blank=True)
    three_star=models.TextField(blank=True)
    four_star=models.TextField(blank=True)
    five_star=models.TextField(blank=True)
    corrective_action=models.TextField(blank=True)
    active=models.BooleanField(default=True)
    order=models.PositiveIntegerField(default=0)
    def requirement_for(self, stars):
        return {1:self.one_star,2:self.two_star,3:self.three_star,4:self.four_star,5:self.five_star}.get(stars,'')
    def __str__(self): return self.code

class Evaluation(models.Model):
    STATUS=[('DRAFT','مسودة'),('FINAL','معتمد')]
    hotel=models.ForeignKey(Hotel,on_delete=models.CASCADE,related_name='evaluations')
    evaluator=models.ForeignKey(User,on_delete=models.SET_NULL,null=True,blank=True)
    visit_date=models.DateField()
    status=models.CharField(max_length=20,choices=STATUS,default='DRAFT')
    general_notes=models.TextField(blank=True)
    score=models.DecimalField(max_digits=5,decimal_places=2,default=0)
    recommendation=models.CharField(max_length=200,blank=True)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    def recalculate(self):
        qs=self.responses.exclude(result='NA')
        total=qs.count(); ok=qs.filter(result='OK').count()
        self.score=round((ok/total)*100,2) if total else 0
        self.recommendation='مستوفي' if self.score>=90 else 'اعتماد مشروط/إعادة زيارة' if self.score>=70 else 'غير مستوفي حالياً'
        self.save(update_fields=['score','recommendation'])

class Response(models.Model):
    RESULT=[('OK','مستوفي'),('NO','غير مستوفي'),('NA','لا ينطبق')]
    evaluation=models.ForeignKey(Evaluation,on_delete=models.CASCADE,related_name='responses')
    criterion=models.ForeignKey(Criterion,on_delete=models.CASCADE)
    result=models.CharField(max_length=2,choices=RESULT,default='OK')
    note=models.TextField(blank=True)
    corrective_action=models.TextField(blank=True)
    class Meta: unique_together=('evaluation','criterion')

class ResponseImage(models.Model):
    response=models.ForeignKey(Response,on_delete=models.CASCADE,related_name='images')
    image=models.ImageField(upload_to='evaluation_images/%Y/%m/')
    caption=models.CharField(max_length=255, blank=True)
    uploaded_at=models.DateTimeField(auto_now_add=True)
