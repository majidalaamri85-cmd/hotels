from django.contrib import admin
from .models import *
admin.site.register(Hotel)
admin.site.register(Section)
admin.site.register(SubSection)
admin.site.register(Criterion)
admin.site.register(Evaluation)
admin.site.register(Response)
admin.site.register(ResponseImage)
