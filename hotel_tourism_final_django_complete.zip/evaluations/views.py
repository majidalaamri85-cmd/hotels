from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib import messages
from .models import *
from .forms import HotelForm, EvaluationForm
from docx import Document
from io import BytesIO

def dashboard(request):
    return render(request,'evaluations/dashboard.html',{'hotels':Hotel.objects.all().order_by('-id')[:20],'evaluations':Evaluation.objects.select_related('hotel').order_by('-id')[:20], 'criteria_count':Criterion.objects.count()})

def hotel_create(request):
    form=HotelForm(request.POST or None)
    if form.is_valid(): form.save(); return redirect('dashboard')
    return render(request,'evaluations/form.html',{'form':form,'title':'إضافة فندق'})

def evaluation_create(request):
    form=EvaluationForm(request.POST or None)
    if form.is_valid():
        ev=form.save(commit=False); ev.evaluator=request.user if request.user.is_authenticated else None; ev.save()
        for c in Criterion.objects.filter(active=True): Response.objects.get_or_create(evaluation=ev, criterion=c, defaults={'corrective_action':c.corrective_action})
        return redirect('evaluation_detail', pk=ev.pk)
    return render(request,'evaluations/form.html',{'form':form,'title':'تقييم جديد'})

def evaluation_detail(request, pk):
    ev=get_object_or_404(Evaluation, pk=pk)
    if request.method=='POST':
        for r in ev.responses.select_related('criterion'):
            r.result=request.POST.get(f'result_{r.id}', r.result)
            r.note=request.POST.get(f'note_{r.id}', '')
            r.corrective_action=request.POST.get(f'action_{r.id}', r.corrective_action)
            r.save()
            for img in request.FILES.getlist(f'images_{r.id}'):
                ResponseImage.objects.create(response=r, image=img)
        ev.recalculate(); messages.success(request,'تم حفظ التقييم وحساب النتيجة')
        return redirect('evaluation_detail', pk=pk)
    sections=Section.objects.prefetch_related('subsections__criteria').order_by('order')
    responses={r.criterion_id:r for r in ev.responses.select_related('criterion')}
    return render(request,'evaluations/evaluation_detail.html',{'ev':ev,'sections':sections,'responses':responses})

def report_docx(request, pk):
    ev=get_object_or_404(Evaluation, pk=pk)
    doc=Document(); doc.add_heading('تقرير تقييم تصنيف فندقي - وزارة التراث والسياحة',0)
    doc.add_paragraph(f'الفندق: {ev.hotel.name}')
    doc.add_paragraph(f'تاريخ الزيارة: {ev.visit_date} - النتيجة: {ev.score}% - التوصية: {ev.recommendation}')
    table=doc.add_table(rows=1, cols=5); table.style='Table Grid'
    for i,h in enumerate(['الكود','البند','الحالة','الملاحظة','الإجراء التصحيحي']): table.rows[0].cells[i].text=h
    for r in ev.responses.select_related('criterion').exclude(result='OK'):
        row=table.add_row().cells; row[0].text=r.criterion.code; row[1].text=r.criterion.title[:300]; row[2].text=r.get_result_display(); row[3].text=r.note; row[4].text=r.corrective_action
    bio=BytesIO(); doc.save(bio); bio.seek(0)
    resp=HttpResponse(bio.read(), content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    resp['Content-Disposition']=f'attachment; filename="hotel_evaluation_{ev.pk}.docx"'
    return resp
