from django import forms
from .models import Hotel, Evaluation
class HotelForm(forms.ModelForm):
    class Meta:
        model=Hotel; fields='__all__'
class EvaluationForm(forms.ModelForm):
    class Meta:
        model=Evaluation; fields=['hotel','visit_date','status','general_notes']
        widgets={'visit_date':forms.DateInput(attrs={'type':'date'})}
